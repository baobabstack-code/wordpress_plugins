// Public-facing JS: add your custom code here.
console.log('Baobabstack Custom Assets: public script loaded');
