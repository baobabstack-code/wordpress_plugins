jQuery(document).ready(function($) {
    console.log('Custom JS loaded!');
    alert('Welcome to my Baobab Tech!');
});
