// Admin-only JS: add your custom code here.
console.log('Baobabstack Custom Assets: admin script loaded');
